import { SubmitWithdrawProps } from "../types";
export declare class SubmitWithdrawMsgValue {
    source: string;
    validator: string;
    constructor(data: SubmitWithdrawProps);
}
